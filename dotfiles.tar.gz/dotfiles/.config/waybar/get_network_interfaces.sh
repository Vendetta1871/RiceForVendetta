#!/bin/bash
OUT="$HOME/.config/waybar/network_interfaces.json"

interfaces=()

for iface in $(ls -1 /sys/class/net); do
    if [ "$iface" = "lo" ]; then
        interfaces+=("$iface")
        continue
    fi

    if [ -e "/sys/class/net/$iface/device" ]; then
        interfaces+=("$iface")
    fi
done

json_array=$(printf '"%s", ' "${interfaces[@]}" | sed 's/, $//')

cat > "$OUT" <<EOF
{
  "network": {
    "interface": [$json_array]
  }
}
EOF
